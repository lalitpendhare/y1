jQuery(document).ready(function(){
		/*jQuery(".acf-field-5a212abaf776c input.input").datepicker({
	    onSelect: function() {
	        var dateObject = jQuery(this).datepicker('getDate');
	        alert(dateObject); 
	    }
	});*/
		/*var start_date = jQuery('.acf-field-5a212abaf776c input.input').val();
		jQuery( '.acf-field-5a212aecf776d input.input' ).datepicker({
			minDate: start_date,
		});*/
		/*var start_date = jQuery('.acf-field-5a212abaf776c input.input').val();
		var date = jQuery('.acf-field-5a212abaf776c input.input').val();
		//alert(date);
		var date = new Date(date);
		alert(date);
		*/
		
		//alert(abc);
});
