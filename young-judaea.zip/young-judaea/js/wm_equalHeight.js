;(function($){
    $.fn.equalHeight = function (option) {
        var $this = this
        var get_height = function(){
            var maxheight=0;
            $this.css("height","")
            $this.each(function(){
                maxheight = $(this).height() > maxheight ? $(this).height() : maxheight;
            })
            $this.height(maxheight)
        }
        var init =function(){
            get_height()
            $(window).bind("resize",get_height)
        }
        $this.destroy = function(){
            $this.css("height","")
            $(window).unbind("resize",get_height)
        }
        init()
        return this
    } 
})(jQuery)