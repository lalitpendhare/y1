<?php
// Template name: Test Flexible
get_header();
require get_template_directory() . '/include/flexible_content.php';
get_footer();